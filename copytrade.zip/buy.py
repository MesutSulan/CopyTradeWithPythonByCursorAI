from raydium.amm_v4 import buy
import sys
import time
from solana.rpc.api import Client

def verify_transaction_success(tx_hash):
    """İşlem başarısını kontrol et"""
    try:
        if not tx_hash:
            print("❌ İşlem hash'i bulunamadı")
            return False
            
        # 5 saniye bekle
        time.sleep(5)
        
        # İşlem durumunu kontrol et
        client = Client("https://api.mainnet-beta.solana.com")
        
        response = client.get_transaction(tx_hash)
        if response["result"]:
            if response["result"]["meta"]["err"] is None:
                print("✅ İşlem onaylandı")
                return True
            else:
                print(f"❌ İşlem başarısız: {response['result']['meta']['err']}")
                return False
        else:
            print("❌ İşlem bulunamadı")
            return False
            
    except Exception as e:
        print(f"❌ İşlem doğrulama hatası: {str(e)}")
        return False

if __name__ == "__main__":
    if len(sys.argv) != 4:
        print("Kullanım: python buy.py <pair_address> <sol_amount> <slippage>")
        sys.exit(1)
        
    pair_address = sys.argv[1]
    sol_amount = float(sys.argv[2])
    slippage = float(sys.argv[3])
    
    try:
        # Alım işlemini gerçekleştir
        tx_hash = buy(pair_address, sol_amount, slippage)
        
        # İşlem başarısını kontrol et
        if tx_hash and verify_transaction_success(tx_hash):
            print("Alım başarılı")
            sys.exit(0)
        else:
            print("Alım başarısız - İşlem doğrulanamadı")
            sys.exit(1)
    except Exception as e:
        print(f"Hata: {str(e)}")
        sys.exit(1)