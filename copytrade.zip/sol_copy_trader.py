import requests
import time
from telebot import TeleBot
import os
from dotenv import load_dotenv
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
import json
from config import *

# .env dosyasını yükle
load_dotenv()

# Global Değişkenler
islenen_tokenler = set()
son_islem_zamani = None
browser = None  # Global tarayıcı değişkeni

def initialize_browser():
    """Tarayıcıyı başlat"""
    global browser
    try:
        if not browser:
            options = Options()
            options.add_argument("--headless=new")
            options.add_argument("--disable-gpu")
            options.add_argument("--no-sandbox")
            options.add_argument("--disable-dev-shm-usage")
            options.add_argument("--disable-extensions")
            options.add_argument("--disable-notifications")
            options.add_argument("--disable-software-rasterizer")
            options.add_argument("--disable-features=VizDisplayCompositor")
            options.add_argument("--disable-features=UseOzonePlatform")
            options.add_argument("--disable-features=WebRTC")
            options.add_experimental_option('excludeSwitches', ['enable-logging'])
            
            try:
                browser = webdriver.Chrome(options=options)
                print("✅ Chrome tarayıcısı başlatıldı")
                return True
            except Exception as chrome_error:
                print(f"❌ Chrome başlatma hatası: {str(chrome_error)}")
                return False
    except Exception as e:
        print(f"❌ Tarayıcı başlatma hatası: {str(e)}")
        return False

def cleanup_browser():
    """Tarayıcıyı temizle ve kapat"""
    global browser
    try:
        if browser:
            browser.quit()
            browser = None
            print("✅ Tarayıcı kapatıldı")
    except Exception as e:
        print(f"❌ Tarayıcı kapatma hatası: {str(e)}")

def save_processed_tokens():
    """İşlenmiş tokenleri dosyaya kaydet"""
    try:
        with open('processed_tokens.json', 'w') as f:
            json.dump(list(islenen_tokenler), f)
        print("✅ İşlenmiş tokenler kaydedildi")
    except Exception as e:
        print(f"❌ İşlenmiş tokenler kaydedilemedi: {e}")

def load_processed_tokens():
    """İşlenmiş tokenleri dosyadan yükle"""
    global islenen_tokenler
    try:
        with open('processed_tokens.json', 'r') as f:
            islenen_tokenler = set(json.load(f))
        print(f"✅ {len(islenen_tokenler)} işlenmiş token yüklendi")
    except FileNotFoundError:
        print("ℹ️ İşlenmiş token dosyası bulunamadı, yeni dosya oluşturulacak")
    except Exception as e:
        print(f"❌ İşlenmiş tokenler yüklenemedi: {e}")

def send_telegram_message(message):
    """Telegram'a mesaj gönder"""
    try:
        bot.send_message(CHAT_ID, message, parse_mode="Markdown")
        print(f"📩 Telegram mesajı gönderildi: {message}")
    except Exception as e:
        print(f"❌ Telegram mesajı gönderilemedi: {e}")

def get_full_page_html(url):
    """Selenium ile tam yüklenmiş HTML'yi alır"""
    global browser
    max_retries = 3
    current_retry = 0
    
    while current_retry < max_retries:
        try:
            if not browser:
                print("ℹ️ Tarayıcı başlatılıyor...")
                if not initialize_browser():
                    print("❌ Tarayıcı başlatılamadı, requests ile devam ediliyor...")
                    response = requests.get(
                        url,
                        headers={
                            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
                        },
                        timeout=5
                    )
                    return response.text
            
            print(f"🌐 Sayfa yükleniyor: {url}")
            browser.get(url)
            time.sleep(1)
            
            return browser.page_source
            
        except Exception as e:
            print(f"❌ Sayfa yükleme hatası (Deneme {current_retry + 1}/{max_retries}): {str(e)}")
            cleanup_browser()
            current_retry += 1
            time.sleep(1)
    
    print("❌ Tarayıcı ile sayfa yüklenemedi, requests ile deneniyor...")
    try:
        response = requests.get(
            url,
            headers={
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
            },
            timeout=5
        )
        return response.text
    except Exception as e:
        print(f"❌ Requests ile sayfa yükleme hatası: {str(e)}")
        return None

def extract_token_details_from_solscan(html):
    """Solscan sayfasından token detaylarını çıkarır"""
    soup = BeautifulSoup(html, "html.parser")
    tokens = []
    unique_mints = set()

    for link in soup.find_all("a", class_="textLink border-transparent"):
        href = link.get("href", "")
        if href.startswith("/token/"):
            mint_address = href.split("/token/")[-1]
            token_name = link.text.strip()

            if (mint_address, token_name) not in unique_mints and not mint_address.startswith("So"):
                unique_mints.add((mint_address, token_name))
                token_data = {
                    "mint": mint_address,
                    "name": token_name
                }
                tokens.append(token_data)
                print(f"🏷️ Token Bulundu: {token_name} ({mint_address})")

    return tokens

def get_dexscreener_pair_info(address):
    """DexScreener'dan token bilgilerini al"""
    try:
        url = f"{DEXSCREENER_TOKEN_URL}/{address}"
        
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "Accept": "application/json",
            "Accept-Language": "tr,en-US;q=0.9,en;q=0.8"
        }
        
        response = requests.get(url, headers=headers, timeout=5)
        
        if response.status_code == 200:
            data = response.json()
            
            if "pairs" in data and data["pairs"]:
                raydium_pairs = [
                    pair for pair in data["pairs"]
                    if pair.get("dexId", "").lower() == "raydium"
                ]
                
                if raydium_pairs:
                    best_pair = max(raydium_pairs, key=lambda x: float(x.get("liquidity", {}).get("usd", 0) or 0))
                    return {
                        "pair_address": best_pair.get("pairAddress"),
                        "liquidity": float(best_pair.get("liquidity", {}).get("usd", 0) or 0),
                        "price": float(best_pair.get("priceUsd", 0) or 0),
                        "volume_24h": float(best_pair.get("volume", {}).get("h24", 0) or 0),
                        "name": best_pair.get("baseToken", {}).get("name", ""),
                        "symbol": best_pair.get("baseToken", {}).get("symbol", "")
                    }
                else:
                    print(f"⚠️ Raydium pair bulunamadı: {address}")
            else:
                print(f"⚠️ Pair bilgisi bulunamadı: {address}")
                
        return None
    except Exception as e:
        print(f"❌ DexScreener API hatası: {str(e)}")
        return None

def get_account_transactions():
    """Takip edilen adresin son işlemlerini al"""
    try:
        global son_islem_zamani
        
        # İlk çalıştırmada before parametresini gönderme
        params = {
            "limit": 1
        }
        if son_islem_zamani:
            params["before"] = son_islem_zamani
        
        payload = {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "getSignaturesForAddress",
            "params": [TAKIP_ADRESI, params]
        }
        
        response = requests.post(SOLANA_RPC_URL, json=payload)
        
        if response.status_code == 200:
            data = response.json()
            
            if "result" in data and data["result"]:
                tx_data = data["result"][0]
                signature = tx_data["signature"]
                block_time = tx_data.get("blockTime", 0)
                
                # Şu anki zaman
                current_time = int(time.time())
                
                # İşlem 5 dakikadan eski mi kontrol et
                if current_time - block_time > 300:  # 300 saniye = 5 dakika
                    return []
                
                # Son işlem kontrolü
                if signature == son_islem_zamani:
                    return []
                    
                son_islem_zamani = signature
                print("\n🔍 Yeni işlem bulundu...")
                print(f"⏰ İşlem zamanı: {time.strftime('%H:%M:%S', time.localtime(block_time))}")
                
                html_content = get_full_page_html(f"https://solscan.io/tx/{signature}")
                if html_content:
                    tokens = extract_token_details_from_solscan(html_content)
                    
                    if tokens:
                        new_tokens = [
                            {
                                "signature": signature,
                                "token_address": token["mint"],
                                "block_time": block_time
                            }
                            for token in tokens
                            if token["mint"] not in islenen_tokenler
                        ]
                        
                        if new_tokens:
                            return new_tokens
                        else:
                            print("ℹ️ Yeni token bulunamadı veya tümü işlenmiş")
            
        return []
            
    except Exception as e:
        print(f"❌ İşlem geçmişi alınamadı: {str(e)}")
        return []

def analyze_transaction(tx_data):
    """İşlem analizini yap"""
    try:
        if not tx_data or "token_address" not in tx_data:
            print("❌ Geçersiz işlem verisi!")
            return None

        token_address = tx_data["token_address"]
        block_time = tx_data["block_time"]
        
        # DexScreener'dan token bilgilerini al
        pair_info = get_dexscreener_pair_info(token_address)
        
        if not pair_info:
            print(f"❌ Token bilgileri alınamadı: {token_address}")
            return None

        # Telegram'a bildirim gönder
        if token_address not in islenen_tokenler:
            message = f"""
💎 *Yeni Token Tespit Edildi*
Token: `{pair_info['name']} ({pair_info['symbol']})`
Adres: `{token_address}`
Fiyat: `${pair_info['price']:.8f}`
24s Hacim: `${pair_info['volume_24h']:,.2f}`
Likidite: `${pair_info['liquidity']:,.2f}`
Pair Adresi: `{pair_info['pair_address']}`
İşlem Zamanı: `{time.strftime('%H:%M:%S', time.localtime(block_time))}`
"""
            send_telegram_message(message)
            
            # Token'i işlenmiş olarak işaretle
            islenen_tokenler.add(token_address)
            save_processed_tokens()

    except Exception as e:
        print(f"❌ İşlem analizi hatası: {str(e)}")
        return None

if __name__ == "__main__":
    print("\n🚀 Sol Copy Trader Başlatılıyor...")
    print(f"👀 Takip Edilen Adres: {TAKIP_ADRESI}")
    
    # Tarayıcıyı başlat
    initialize_browser()
    
    # İşlenmiş tokenleri yükle
    load_processed_tokens()
    
    print("\n⏳ İşlemler takip ediliyor...")
    print("ℹ️ Her 10 saniyede bir kontrol yapılıyor...")
    
    try:
        while True:
            try:
                # Son işlemleri al
                transactions = get_account_transactions()
                
                if transactions:
                    for tx in transactions:
                        # İşlem analizi yap
                        analyze_transaction(tx)
                
                # 10 saniye bekle
                time.sleep(10)
                
            except Exception as e:
                print(f"\n❌ Hata oluştu: {str(e)}")
                time.sleep(10)
    except KeyboardInterrupt:
        print("\n\n🛑 Bot durduruldu!")
    finally:
        # Program sonlandığında tarayıcıyı temizle
        cleanup_browser()
