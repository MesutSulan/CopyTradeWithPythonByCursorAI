from dotenv import load_dotenv
import os
from telebot import TeleBot

# .env dosyasını yükle
load_dotenv()

# Telegram Bot Ayarları
TELEGRAM_TOKEN = os.getenv("TELEGRAM_TOKEN")
CHAT_ID = os.getenv("CHAT_ID")
bot = TeleBot(TELEGRAM_TOKEN)

# API URL'leri
SOLANA_RPC_URL = "https://api.mainnet-beta.solana.com"
DEXSCREENER_TOKEN_URL = "https://api.dexscreener.com/latest/dex/tokens"

# Takip Edilecek Adres
TAKIP_ADRESI = ""