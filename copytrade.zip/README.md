# Solana Token Takip Botu

Bu bot, belirtilen bir Solana adresini takip ederek, bu adres yeni bir token aldığında Telegram üzerinden bildirim gönderir.

## Özellikler

- Solana adresindeki son işlemleri takip eder
- Yeni token alımlarını tespit eder
- Son 5 dakika içindeki işlemleri filtreler
- Telegram üzerinden otomatik bildirim gönderir
- Token adı, adresi, fiyatı, hacmi ve likidite bilgilerini gösterir

## Kurulum

1. Repository'i klonlayın:
```bash
git clone https://github.com/KULLANICI_ADINIZ/REPO_ADINIZ.git
cd REPO_ADINIZ
```

2. Gerekli paketleri yükleyin:
```bash
pip install -r requirements.txt
```

3. `.env` dosyası oluşturun:
```
TELEGRAM_TOKEN=your_telegram_token_here
CHAT_ID=your_chat_id_here
TAKIP_ADRESI=your_solana_address_to_track
SOLANA_RPC_URL=your_solana_rpc_url (opsiyonel)
```

## Kullanım

Bot'u başlatmak için:
```bash
python sol_copy_trader.py
```

## Telegram Bot Kurulumu

1. Telegram'da [@BotFather](https://t.me/botfather) ile konuşun
2. `/newbot` komutunu kullanarak yeni bir bot oluşturun
3. Size verilen token'ı `.env` dosyasına ekleyin
4. Bot'unuza mesaj gönderin ve [@userinfobot](https://t.me/userinfobot)'a mesaj göndererek chat ID'nizi öğrenin
5. Chat ID'nizi `.env` dosyasına ekleyin

## Lisans

Bu proje MIT Lisansı altında lisanslanmıştır. 